rename 's/drugs_ca/drugsca/' *.pkl
rename 's/drugs_fda/drugsfda/' *.pkl
rename 's/parsed_cnef/cnefe/' *.pkl
rename 's/parsed_iptu/iptu/' *.pkl
rename 's/parsed_lei/lei/' *.pkl
rename 's/parsed_sec/sec/' *.pkl
rename 's/tripadvisor_data/tripadvisor/' *.pkl
rename 's/yelp_data/yelp/' *.pkl

