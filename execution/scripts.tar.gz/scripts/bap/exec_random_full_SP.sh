echo ":::: Simples"

#time python3 calculate_Signatures.py -process 8 -dt sp_cnefe -s 2 -encrypt 256 /home/thiago/samples/SP_Adresses/cnefe/simples/ |&  tee random_simple_sp_cnefe.log
time python3 calculate_Signatures.py -e iso-8859-1 -process 8 -dt sp_iptu -s 2 -encrypt 256 /home/thiago/samples/SP_Adresses/iptu/simples/ |&  tee random_simple_sp_iptu.log

mv /home/thiago/pyPAS/data/signatures/*.pkl /home/thiago/pyPAS/data/signatures/random_simples/

echo ":::: Combinado"

#time python3 calculate_Signatures.py -process 8 -dt sp_cnefe -s 2 -encrypt 256 /home/thiago/samples/SP_Adresses/cnefe/combinado/ |&  tee random_combinado_sp_cnefe.log
#time python3 calculate_Signatures.py -e iso-8859-1 -process 8 -dt sp_iptu -s 2 -encrypt 256 /home/thiago/samples/SP_Adresses/iptu/combinado/ |&  tee random_combinado_sp_iptu.log


mkdir /home/thiago/pyPAS/data/signatures/random_combinado
#mv /home/thiago/pyPAS/data/signatures/*.pkl /home/thiago/pyPAS/data/signatures/random_combinado/

echo ":::: Full"
#time python3 calculate_Signatures.py -file True -process 4 -dt sp_cnefe -s 2 -encrypt 256 /home/thiago/dados/SP_Adresses/parsedcnef.csv |&  tee sp_cnefe.log
#time python3 calculate_Signatures.py -file True  -e iso-8859-1 -process 4 -dt sp_iptu -s 2 -encrypt 256 /home/thiago/dados/SP_Adresses/parsediptu.csv |&  tee sp_iptu.log

#mkdir /home/thiago/pyPAS/data/signatures/full
#mv /home/thiago/pyPAS/data/signatures/*.pkl /home/thiago/pyPAS/data/signatures/full/

