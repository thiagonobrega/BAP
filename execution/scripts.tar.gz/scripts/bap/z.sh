
#echo "FEII"
#time python3 calculate_Signatures.py -file True -process 8 -dt feii_lei -s 2 -encrypt 256 /home/thiago/dados/fei/parsed_lei.csv |&  tee log_ful_feii_lei.log
#time python3 calculate_Signatures.py -file True -process 8 -dt feii_sec -s 2 -encrypt 256 /home/thiago/dados/fei/parsed_sec.csv |&  tee log_ful_feii_sec.log

echo "DRUGS"
time python3 calculate_Signatures.py -file True -process 8 -dt drugs_fda -s 2 -encrypt 1024 /home/thiago/dados/drugs/drugsfda.csv |& tee log_ful_drugs_fda.log
time python3 calculate_Signatures.py -file True -process 8 -dt drugs_ca -s 2 -encrypt 1024 /home/thiago/dados/drugs/drugsca.csv |& tee log_ful_drugs_ca.log
