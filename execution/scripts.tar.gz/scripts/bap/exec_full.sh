echo "US_VOTERS"
time python3 calculate_Signatures.py -file True -dt voters_nc -s 4 -process 8 -encrypt 1024 /home/thiago/dados/us_voters/ncvoter.csv |& tee log_full_ncvoters.txt
time python3 calculate_Signatures.py -file True -dt voters_ohio -s 4 -process 8 -encrypt 1024 /home/thiago/dados/us_voters/ohio_voters.csv |& tee log_ohiovoters.txt

echo "FEII"
time python3 calculate_Signatures.py -file True -process 8 -dt feii_lei -s 2 -encrypt 256 /home/thiagonobrega/zexp/odata/feii/parsed_lei.csv |&  tee log_ful_feii_lei.log
time python3 calculate_Signatures.py -file True -process 8 -dt feii_sec -s 2 -encrypt 256 /home/thiagonobrega/zexp/odata/feii/parsed_sec.csv |&  tee log_ful_feii_sec.log

echo "SP"
time python3 calculate_Signatures.py -file True -process 4 -dt sp_cnefe -s 2 -encrypt 256 /home/thiago/dados/SP_Adresses/parsedcnef.csv |&  tee log_ful_sp_cnefe.log
time python3 calculate_Signatures.py -e iso-8859-1 -file True -process 4 -dt sp_iptu -s 2 -encrypt 256 /home/thiago/dados/SP_Adresses/parsediptu.csv |&  tee log_ful_sp_iptu.log

echo "DRUGS"
time python3 calculate_Signatures.py -file True -process 4 -dt drugs_fda -s 4 -encrypt 1024 /home/thiago/dados/drugs/drugsfda.csv |& tee log_ful_drugs_fda.log
time python3 calculate_Signatures.py -file True -process 4 -dt drugs_ca -s 4 -encrypt 1024 /home/thiago/dados/drugs/drugsca.csv |& tee log_ful_drugs_ca.log

echo "PE"
time python3 calculate_Signatures.py -file True -process 8 -dt pe_mpog -s 2 -encrypt 256 /home/thiago/dados/PublicEmployees/mpog.csv |&  tee log_ful_pe_mpgo.log
time python3 calculate_Signatures.py -file True -process 8 -dt pe_tce -s 2 -encrypt 256 /home/thiago/dados/PublicEmployees/tce.csv |& tee log_ful_pe_tce.log

echo "REST"
time python3 calculate_Signatures.py -file True -dt rest_tripadvisor -s 2 -process 8 -encrypt 2048 /home/thiago/dados/Restaurants/tripadvisor_data.csv |& tee log_ful_log_trip.txt
time python3 calculate_Signatures.py -file True -dt rest_yelp -s 2 -process 8 -encrypt 2048 /home/thiago/dados/Restaurants/yelp_data.csv |& tee log_ful_log_yelp.txt

