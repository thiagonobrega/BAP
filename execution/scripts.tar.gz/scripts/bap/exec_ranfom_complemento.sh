echo ":::: Simples"
#echo "SP"
#time python3 calculate_Signatures.py -process 8 -dt sp_cnefe -s 2 -encrypt 256 /home/thiago/samples/SP_Adresses/cnefe/simples/ |&  tee random_simple_sp_cnefe.log
#time python3 calculate_Signatures.py -e iso-8859-1 -process 8 -dt sp_iptu -s 2 -encrypt 256 /home/thiago/samples/SP_Adresses/iptu/simples/ |&  tee random_simple_sp_iptu.log

#echo "US_VOTERS"
#time python3 calculate_Signatures.py -dt voters_nc -s 1 -process 8 -encrypt 1024 /home/thiago/samples/us_voters/nc/simples/ |& tee log_full_ncvoters.log
#time python3 calculate_Signatures.py -dt voters_ohio -s 1 -process 8 -encrypt 1024 /home/thiago/samples/us_voters/oh/simples/|& tee log_ohiovoters.log

echo ":::: Combinado"
#echo "SP"
#time python3 calculate_Signatures.py -process 8 -dt sp_cnefe -s 2 -encrypt 256 /home/thiago/samples/SP_Adresses/cnefe/combinado/ |&  tee random_combinado_sp_cnefe.log
#time python3 calculate_Signatures.py -e iso-8859-1 -process 8 -dt sp_iptu -s 2 -encrypt 256 /home/thiago/samples/SP_Adresses/iptu/combinado/ |&  tee random_combinado_sp_iptu.log

echo "US_VOTERS"
time python3 calculate_Signatures.py -dt voters_nc -s 1 -process 8 -encrypt 1024 /home/thiago/samples/us_voters/nc/combinado/ |& tee log_full_ncvoters.log
time python3 calculate_Signatures.py -dt voters_ohio -s 1 -process 8 -encrypt 1024 /home/thiago/samples/us_voters/oh/combinado/|& tee log_ohiovoters.log
echo "PE"
time python3 calculate_Signatures.py -process 8 -dt pe_cgu -s 1 -encrypt 2048 /home/thiago/samples/PublicEmployees/cgu/combinado/ |& tee random_combinado_pe_tce.log


#mkdir /home/thiago/pyPAS/data/signatures/random_combinado
#mv /home/thiago/pyPAS/data/signatures/*.pkl /home/thiago/pyPAS/data/signatures/random_combinado/

 
