echo ":::: SP_Adresses"

mkdir -p /home/thiago/samples/SP_Adresses/cnefe
mkdir -p /home/thiago/samples/SP_Adresses/iptu

##/home/thiago/dados/SP_Adresses/parsedcnef.csv
##observar se o formato da saida do sample
#/home/thiago/dados/SP_Adresses/parsed_iptu.csv

echo "CNEFE Simples"
python3 randomSampler.py --infile /home/thiago/dados/SP_Adresses/parsedcnef.csv --nsamples 5 --sample_size 0.0025 0.005 0.01 0.015 0.02 --use-percent --outdir /home/thiago/samples/SP_Adresses/cnefe/simples/
echo "CNEFE Combinado"
python3 randomSampler.py --infile /home/thiago/dados/SP_Adresses/parsedcnef.csv --nsamples 5 --sample_size 8038 15750 31501 47256 63015  --outdir /home/thiago/samples/SP_Adresses/cnefe/combinado/

echo "IPTU Simples"
python3 randomSampler.py --infile /home/thiago/dados/SP_Adresses/parsediptu.csv --nsamples 5 --sample_size 0.0025 0.005 0.01 0.015 0.02 --use-percent --outdir /home/thiago/samples/SP_Adresses/iptu/simples/
echo "IPTU Combinado"
python3 randomSampler.py --infile /home/thiago/dados/SP_Adresses/parsediptu.csv --nsamples 5 --sample_size 8038 15750 31501 47256 63015  --outdir /home/thiago/samples/SP_Adresses/iptu/combinado/

