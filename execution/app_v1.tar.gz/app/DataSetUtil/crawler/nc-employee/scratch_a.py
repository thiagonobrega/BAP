# -*- coding: utf-8 -*-
"""
Created on Mon Nov  6 11:18:43 2017

@author: Thiago
"""

import scrapy


def first(sel, xpath):
    return sel.xpath(xpath).extract_first()


class YoutubeChannelLister(scrapy.Spider):
    name = 'channel-lister'
    youtube_channel = 'portadosfundos'
    start_urls = ['https://www.youtube.com/user/%s/videos' % youtube_channel]

    def parse(self, response):
        for sel in response.css("ul#channels-browse-content-grid > li"):
            yield {
                'link': response.urljoin(first(sel, './/h3/a/@href')),
                'title': first(sel, './/h3/a/text()'),
                'views': first(sel, ".//ul/li[1]/text()"),
            }

class SpiderSimples(scrapy.Spider):
    name = 'meuspider'
    start_urls = ['http://example.com']

    def parse(self, response):
        self.log('Visitei o site: %s' % response.url)
        

    
process = CrawlerProcess({
        'USER_AGENT': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)'
})

process.crawl(spider)
process.start() 
    
# r1
#from twisted.internet import reactor
#from scrapy.crawler import Crawler
#from scrapy.crawler import CrawlerProcess
#from scrapy.settings import Settings
#from scrapy import log

#spider = FollowAllSpider(domain='scrapinghub.com')
#spider = SpiderSimples()
#crawler = Crawler(Settings())
#crawler.configure()
#crawler.crawl(spider)
#crawler.start()
#log.start()
#reactor.run()