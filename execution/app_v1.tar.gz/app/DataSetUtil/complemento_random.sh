echo "FDA Combinado"
python3 randomSampler.py --infile /home/thiago/dados/drugs/drugsfda.csv --nsamples 5 --sample_size 1279 2557 5115 7672 10229 --outdir /home/thiago/samples/drugs/fda/combinado/	
echo "CA Combinado"
python3 randomSampler.py --infile /home/thiago/dados/drugs/drugsca.csv --nsamples 5 --sample_size 1279 2557 5115 7672 10229 --outdir /home/thiago/samples/drugs/ca/combinado/
echo "CGU Combinado"
python3 randomSampler.py --infile /home/thiago/dados/PublicEmployees/cgu.csv --nsamples 5 --sample_size 640 1281 2561 3842 5123 --outdir /home/thiago/samples/PublicEmployees/cgu/combinado/
echo "MPOG Combinado"
python3 randomSampler.py --infile /home/thiago/dados/PublicEmployees/mpog.csv --nsamples 5 --sample_size 640 1281 2561 3842 5123 --outdir /home/thiago/samples/PublicEmployees/mpog/combinado/				
