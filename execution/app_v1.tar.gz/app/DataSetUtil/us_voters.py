import zipfile
import io
import csv
from datetime import datetime
from parsers import base
import os

from datetime import datetime

def fix_date(din):
    d = str(din)
    dt = datetime.strptime(str(d),'%Y-%m-%d')
    newdate = str(dt.day) + "/" + str(dt.month) + "/" + str(dt.year)
    return newdate

in_dir ="F:"+os.path.sep+"z_dados"+os.path.sep+"us_voters"+os.path.sep
in_dir =os.path.sep+"home/thiago/dados"+os.path.sep+"us_voters"+os.path.sep
file = "ohio_voters_striped_full.csv"
data = base.readData(in_dir+file, sep=",")

data['birth_date'] = data['birth_date'].apply(fix_date)
data['register_date'] = data['register_date'].apply(fix_date)

base.writeData(data,in_dir+'ohio_voters.csv')

