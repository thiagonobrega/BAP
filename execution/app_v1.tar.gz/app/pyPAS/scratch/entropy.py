'''
Created on 18 de jul de 2017

@author:  Thiago Nobrega
@mail: thiagonobrega@gmail.com
'''

# from multiprocessing import Pool
# from collections import Counter
# from math import log2
# # from numba import jit
# 
# 
# # --- data & parameters--- #
# frequenciesAdjectives = open('/home/christian/results/gender/frequenciesAdjectivesGivenNouns_UK.txt', 'r')
# results = open('/home/christian/results/gender/JensenShannonDivergences_ukWaC.txt', 'w')
# cores = 16
# 
# 
# # --- functions --- #
# # calculates Jason-Shannon Divergence from tuple of two nouns and their associated adjective probabilities in dictionaries p and q
# def JSD(nounTuple):
#     noun1, noun2, p, q = nounTuple
#     jsd = 0.0
#     m = p + q
#     for key in m:
#         m_key = 0.5 * m[key]
#         if key in p:
#             p_key = p[key]
#             jsd += 0.5 * p_key * log2(p_key/m_key)
#         if key in q:
#             q_key = q[key]
#             jsd += 0.5 * q_key * log2(q_key/m_key)
#     return noun1, noun2, jsd
# 
# 
# def jobGenerator(tuples):
#     for index, (noun, adjectives) in enumerate(tuples):
#         for noun2, adjectives2 in tuples[index:]:
#             yield noun, noun2, adjectives, adjectives2
# 
# 
# # --- processing --- #
# # ignore header
# frequenciesAdjectives.readline()
# 
# # make list of tuples of nouns and dictionaries containing their preceding adjective frequencies
# nounAdjectives = []
# for line in frequenciesAdjectives:
#     adjectives = Counter()
#     line = line.strip().lower().split("\t")
#     noun = line[0]
#     adjectiveList = [pair.split(" ") for pair in line[2:]]
#     frequencySum = sum(int(frequency) for _, frequency in adjectiveList)
#     for adjective, frequency in adjectiveList:
#         probability = int(frequency)/frequencySum
#         adjectives[adjective] = probability
#     nounAdjectives.append((noun, adjectives))
# 
# # make generator of (noun, noun2, adjectives, adjectives2)-tuples
# jobs = jobGenerator(nounAdjectives)
# 
# # shortcut results.write and write header
# resultswrite = results.write
# resultswrite(u"noun1\tnoun2\tjensenShannonDivergence")
# 
# # calculate JSDs in parallel and write to file
# pool = Pool(cores)
# for noun1, noun2, jsd in pool.imap_unordered(JSD, jobs, chunksize=500000):
#     resultswrite(u"\n{noun1}\t{noun2}\t{jsd}".format_map(locals()))
# pool.close()


#!/usr/bin/python
#
# Stolen from Ero Carrera
# http://blog.dkbza.org/2007/05/scanning-data-for-entropy-anomalies.html
import math, string, sys, fileinput

### usado
def H(data):
    if not data:
        return 0
    entropy = 0
    
    for bf in data:
        #p_x = float(bf.filter.count(1))/ bf.filter.length()
        p_x = float(bf.filter.count(1))/ (len(data) * bf.filter.length())
        if p_x > 0:
            entropy += - p_x*math.log(p_x, 2)
    return entropy

# for i in z.keys():
#     print(i)
#     print(H(z[i]))

## da internet

def range_bytes (): return range(256)
def range_printable(): return (ord(c) for c in string.printable)

def Ho(data, iterator=range_bytes):
    if not data:
        return 0
    entropy = 0
    for x in iterator():
        p_x = float(data.count(chr(x)))/len(data)
        if p_x > 0:
            entropy += - p_x*math.log(p_x, 2)
    return entropy

def main ():
    for row in fileinput.input():
        string = row.rstrip('\n')
        print ("%s: %f" % (string, Ho(string, range_printable)))

a = ['a','a','a','b']
b = ['a','b']
Ho(a)
Ho(b)

for str in ['gargleblaster', 'tripleee', 'magnus', 'lkjasdlk',
               'aaaaaaaa', 'sadfasdfasdf', '7&wS/p(']:
    print ("%s: %f" % (str, Ho(str, range_printable)))


# def entropy(labels):
#     """ Computes entropy of 0-1 vector. """
#     n_labels = len(labels)
# 
#     if n_labels <= 1:
#         return 0
# 
#     counts = np.bincount(labels)
#     probs = counts[np.nonzero(counts)] / n_labels
#     n_classes = len(probs)
# 
#     if n_classes <= 1:
#         return 0
#     return - np.sum(probs * np.log(probs)) / np.log(n_classes)
