'''
Created on 18 de jul de 2017

@author:  Thiago Nobrega
@mail: thiagonobrega@gmail.com
'''

from analytics.Signatures import SimilaritySignatures
from analytics.Signatures import *

a = SimilaritySignatures.load("../data/signatures/ncvoter-a_random_selected_10000.pkl")
b = SimilaritySignatures.load("../data/signatures/ohio-b_random_selected_10000.pkl")

print("Done!")

header_a = a.columns_names.copy()
header_b = b.columns_names.copy()

#coloca um campo embranco para iqualhar a tabela
header_b.insert(0,'')

import pandas as pd
import numpy as np
import scipy as sp


I = pd.Index(a.columns_names, name="rows")
C = pd.Index(b.columns_names, name="columns")

pdata = pd.DataFrame(pd.np.empty((len(a.columns_names),len(b.columns_names))) * pd.np.nan, index=I, columns=C)

#column,row
pdata['res_state']['mail_zipcode'] = 0
    
dados = []
dados.append(header_b)
    
for c_a in a.columns_names:
    linha = []
    linha.append(c_a) # isso ta parecendo errado
    for c_b in b.columns_names:
        #val = b.minhash[c_b].jaccard(a.minhash[c_a])
        val = SimilaritySignatures.simMinHash(a,c_a,b,c_b)
        #val = mhs_1[c1].jaccard(mhs_2[c2])
        pdata[c_b][c_a] = val
        linha.append(val)
            
    dados.append(linha)

#recupera a linha com maior valor da coluna lastname
pdata['lastname'].argmax()
pdata['lastname'].max()
pdata['lastname'].idxmax(axis=1)

# recupera uma linha e mostra o maior valor
pdata.loc[['last_name']].idxmax(axis=1)
pdata.loc[['last_name']].max()

    
print(SimilaritySignatures.simEntropy(a,'last_name',b,'lastname'))
print(SimilaritySignatures.simEntropy(a,'last_name',b,'res_city'))
# print(b.simEntropy(a,'last_name'))

print(a.data_length['last_name'])
print(b.data_length['lastname'])
print(SimilaritySignatures.simDataLength(a,'last_name',b,'lastname'))
print(SimilaritySignatures.simDataLength(b,'lastname',a,'last_name'))

a.setDataLength(confidence=0.1)
b.setDataLength(confidence=0.1)
print(a.data_length['last_name'])
print(b.data_length['lastname'])

print(SimilaritySignatures.simDataLength(a,'last_name',b,'lastname'))
print(SimilaritySignatures.simDataLength(b,'lastname',a,'last_name'))

# print(a.simDataLength(b,'last_name'))
# print(b.simDataLength(b,'last_name'))

mhd = generateMinHashSimMatix(a,b)
ed = generateEntropySimMatix(a,b)
dld = generateDataLengthSimMatix(a,b)


pd.DataFrame(mhd.values, mhd.columns, mhd.index)


## possivel solucao
#for i in b.columns_names:
#    row = ed[i].idxmax(axis=1)
#    v = ed[i][row]
#    print(i+"::"+row+"::"+str(v))

print(20*"=")
#t_mhd[t_mhd['last_name']==0] = None

t_mhd = mhd.T.copy()

for i in mhd.columns:
    row = mhd[i].idxmax(axis=1)
    z=t_mhd[row].copy()
    z[z==0] = None
    mean = t_mhd[row].mean()
    mean2 = z.mean()
    v = mhd[i][row]
    print(i+"::"+row+"::"+str(v) + ":"+str(mean)+":"+str(mean2))


p = (mhd + ed)/2
p['lastname'][p['lastname'] >= 1.5*p['lastname'].mean()]

p = (mhd * 6)/10+( ed * 4)/10
tp = p.T.copy()

theta = 0.8
atheta = 0.05
for col in p.columns:
    coluna = p[col]
    coluna[coluna==0] = None
    media_coluna = coluna.mean()
    
    coluna_selecionada = coluna[coluna >= (1+theta)*media_coluna ]
    if len(coluna_selecionada) > 0:
        chave_linha = coluna_selecionada.idxmax(axis=1)
        linha = tp[chave_linha]
        media_linha = linha.mean()
        linha_selecionada = linha[linha >= (1+theta)*media_linha ]
        if len(linha_selecionada) == 0:
            # a coluna esta correta
            print("0")
            print(col,chave_linha,coluna.max())
            pass
        else:
            if linha_selecionada.idxmax(axis=1) == col:
                #linha e coluna concordam (match)
                print("-")
                print(col,chave_linha,coluna.max())
            else:
                n = min(linha_selecionada.max() ,coluna_selecionada.max())
                m = max(linha_selecionada.max() ,coluna_selecionada.max())
                dt = 1 - (n/m)
                if  dt <= atheta:
                    print(dt)
                    print(col,chave_linha,coluna.max())
                pass
    
    # default
    row = p[i].idxmax(axis=1)
    z=tp[row].copy()
    z[z==0] = None
    
    # means
    mean = t_mhd[row].mean()
    mean2 = z.mean()
    v = mhd[i][row]
    print(i+"::"+row+"::"+str(v) + ":"+str(mean)+":"+str(mean2))
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    