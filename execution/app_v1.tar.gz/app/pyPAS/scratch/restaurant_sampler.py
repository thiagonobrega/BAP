# -*- coding: utf-8 -*-
"""
Created on Wed Aug  9 14:15:34 2017

@author: Thiago
"""
import pandas as pd
import numpy as np
import csv

dir='F:\\Arquivo_Morto\\DataSet\\SAC\\'

trip = pd.read_csv(dir +'tripadvisor_clean.csv', sep=",").replace(np.nan, '', regex=True)

yelp = pd.read_csv(dir +'yelp_clean.csv', sep=",",dtype={'postal_code': object,'is_open': object}).replace(np.nan, '', regex=True)

sample_size = [ 100,1000,5000,10000 ]
samples_names = ['a','b','c','d','e']


def sample(sample_size,samples,data):
    ldata = {}
    ktext = "_random_selected_"
    
    for i in sample_size:
        for s in samples:
            key = s + ktext + str(i)
            ldata[key] = data.sample(n=i,replace=True)
    return ldata


def save_samples(samples,dataSet_name,outputdir):
    for k in samples.keys():
        outFile = outputdir + dataSet_name + "_" + k + ".csv"
        outdata = samples[k]
        outdata.to_csv(outFile,index=False,encoding='utf-8',quoting=csv.QUOTE_ALL)

outdir='F:\\Arquivo_Morto\\DataSet\\SAC\\samples\\'

save_samples(sample(sample_size,samples_names,trip),"tripadvisor",outdir)

save_samples(sample(sample_size,samples_names,yelp),"yelp",outdir)