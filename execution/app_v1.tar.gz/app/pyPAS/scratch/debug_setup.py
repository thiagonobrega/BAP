# -*- coding: utf-8 -*-
"""
Created on Fri Jan 19 12:59:53 2018

@author: Thiago
"""

file1 = 'fda_full_selected_1.pkl'
file2 = 'drugsca_full_selected_1.pkl'
i = theta = 0.1

a = SimilaritySignatures.load(dir1 + file1)
b = SimilaritySignatures.load(dir2 + file2)

result = calculateSimilarityMatrix2(a,b,theta=0.7)
col = 'DATRECEIVED'
'REPORT_TYPE_ENG'
'DRUGINVOLV_ENG'


Signatures.generateMinHashSimMatix(a,b)

