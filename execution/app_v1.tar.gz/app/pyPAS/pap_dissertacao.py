# encoding: utf-8
# encoding: iso-8859-1
# encoding: win-1252

'''
Created on 9 de ago de 2017

@author: Thiago
'''

from analytics.Signatures import SimilaritySignatures
from analytics import Signatures
import pandas as pd
import numpy as np
from util import config
import time

def check(dirToScreens):
    import os
    from os import path
    files = []
    for f in os.listdir(dirToScreens):
        if f.endswith(".pkl"):
            files.append(f)
    return files

def calculateSimilarityMatrix(a,b,theta = 0.8,atheta = 0.05):
    
    mhd = Signatures.generateMinHashSimMatix(a,b)
    ed = Signatures.generateEntropySimMatix(a,b)
    
    #p = (mhd + ed)/2
    p = (mhd * 8)/10+( ed * 2)/10
    print(p)
    tp = p.T.copy()
    
    #a,b,sim_val
    result = []
    
    for col in p.columns:
        coluna = p[col]
        coluna[coluna==0] = None
        media_coluna = coluna.mean()
        
        coluna_selecionada = coluna[coluna >= (1+theta)*media_coluna ]
        if len(coluna_selecionada) > 0:
            chave_linha = coluna_selecionada.idxmax(axis=1)
            linha = tp[chave_linha]
            media_linha = linha.mean()
            linha_selecionada = linha[linha >= (1+theta)*media_linha ]
            if len(linha_selecionada) == 0:
                # a coluna esta correta INVESTIGAR
                print("0") 
                #print(col,chave_linha,coluna.max())
                pass
            else:
                if linha_selecionada.idxmax(axis=1) == col:
                    #linha e coluna concordam (match)
                    #print("-")
                    #print(col,chave_linha,coluna.max())
                    r = (chave_linha,col,coluna.max())
                    #DEBUG
                    #print(r)
                    result.append(r)
                else:
                    n = min(linha_selecionada.max() ,coluna_selecionada.max())
                    m = max(linha_selecionada.max() ,coluna_selecionada.max())
                    dt = 1 - (n/m)
                    if  dt <= atheta:
                        #INVESTIGAR
                        print("1")
                        print(dt)
                        # chave linhavem doa
                        # col vem do b
                        r = (chave_linha,col,coluna.max())
                        result.append(r)
                        #print(col,chave_linha,coluna.max())
                    pass
    
    return result

def calculateSimilarityMatrix2(a,b,theta = 0.3,atheta = 0.05):
    
    mhd = Signatures.generateMinHashSimMatix(a,b)
    ed = Signatures.generateEntropySimMatix(a,b)
    
    #p = (mhd + ed)/2
    p = (mhd * 6)/10+( ed * 4)/10
    #print(p)
    tp = p.T.copy()
    
    #a,b,sim_val
    result = []
    
    for col in p.columns:
        coluna = p[col]
        coluna[coluna==0] = None
        media_coluna = coluna.mean()
        
        coluna_selecionada = coluna[coluna >= (1+theta)*media_coluna ].dropna()
        
        if len(coluna_selecionada) > 0:
            chave_linha = coluna_selecionada.idxmax()#(axis=1)
            linha = tp[chave_linha]
            linha = linha[linha >= (1+theta)*linha.mean() ].dropna()
            
            wflag = False
            if len(linha) > 0:
                wflag = True
            
            while (wflag):
                if wflag:
                    if linha.idxmax() == col:
                        add_flag = True
                        # Checa se se o valor ja foi adcionado
                        for e in result:
                            if e[0] == chave_linha:
                                add_flag = False
                        if add_flag:
                            r = (chave_linha,col,linha.max())
                            result.append(r)
                            wflag = False
                        else:
                            linha = linha.drop(linha.idxmax())
                            if len(linha) == 0:
                                wflag = False
                    else:
                        # se o maior valor da coluna nao for iqual a coluna pegue o segundo maior
                        if p[linha.idxmax()].idxmax() != col:
                            linha = linha.drop(linha.idxmax())
#                            linha.drop(p[linha.idxmax()].idxmax().index[0])
#                            key = linha.drop(linha.idxmax())
#                            linha[key]
                        if len(linha) == 0:
                            wflag = False
    
    return result

def getGoldStandart(name):
    from configparser import ConfigParser
    cparser = ConfigParser()
    cparser.read('confs/gold_standards.ini')
    g = cparser.get(name, 'result').replace('\n','').split('#')
    
    
    gabarito = []
    for op in g:
        v = op.split(',')
        gabarito.append((v[0],v[1]))
    return gabarito

def corrigeResultado(gabarito,results):
    '''
        Retorna o true match,true non match,false match
    '''
    tm = []
    result_nf = []
    for r in results:
        result_nf.append((r[0],r[1]))
        for g in gabarito:
            if (r[0] == g[0]) & (r[1] == g[1]):
                tm.append(g)
    fm = set(result_nf) - set(tm)
    tnm = set(gabarito) - set(tm)
    return tm,tnm,fm

def exec_pap(headers, dir1, dir2, gab, outdir = ""):
    gabarito = getGoldStandart(gab)
    files_dir1 = check(dir1)
    files_dir2 = check(dir2)
    saida = []
    saida_qualitativa = ""
    for file1 in files_dir1:
        for file2 in files_dir2:
            saida_qualitativa += 10 * "#"
            saida_qualitativa += " " + str(file1) + "-" + str(file2) + "\n"
            print(file1)
            sample_size1 = int(file1.split('_')[-1].split('.')[0])
            filename1 = file1.split('_')[0] + '-' + file1.split('_')[1]
            sample_size2 = int(file2.split('_')[-1].split('.')[0])
            filename2 = file2.split('_')[0] + '-' + file2.split('_')[1]
            if sample_size1 == sample_size2:
                a = SimilaritySignatures.load(dir1 + file1)
                b = SimilaritySignatures.load(dir2 + file2)
                #for i in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:
                for i in [ 0.7,0.9]:
                    limiar = 5 * '-' + str(i) + 5 * '-' 
                    print(limiar)
                    saida_qualitativa += limiar + "\n"
                    start = time.time()
                    #result = calculateSimilarityMatrix(a, b, theta=i, atheta=0.01)
                    result = calculateSimilarityMatrix2(a, b, theta=i, atheta=0.01)
                    #print(result)
                    end = time.time()
                    tm, tnm, fm = corrigeResultado(gabarito, result)
                    print("TM",tm)
                    print("TNM",tnm)
                    print("FM",fm)
                    #print(tm,tnm,fm)
                    if (len(tm) + len(fm)) == 0:
                        precision = 0
                    else:
                        precision = len(tm) / (len(tm) + len(fm))
                    if (len(tm) + len(tnm)) == 0:
                        recall =0 
                    else:
                        recall = len(tm) / (len(tm) + len(tnm))
                    if (precision + recall) == 0:
                        f1 = 0
                    else:
                        f1 = 2 * ((precision * recall) / (precision + recall))
                    s = [gab, filename1, filename2, sample_size1, i, len(tm), len(tnm), len(fm), precision, recall, f1, end - start, start, end]
                    saida.append(s)
                    for res in result:
                        saida_qualitativa += "\t " + str(res) + "\n"
    
    import os
    os.makedirs(outdir,exist_ok=True)
    config.write(outdir+'saida-full-'+gab+'.csv', headers, saida)
    f = open(outdir+'saida-qualitativa-'+gab+'.txt', 'w')
    f.write(saida_qualitativa)
    f.close()
    
    return result

if __name__ == '__main__':
    
    headers = ['gab','file_1','file_2','sample_size','threshold','tm','tnm','fm','precision','recall','f1','detlta','t1','t2']
    
    indir = 'C:\\Users\\Thiago\\Dropbox\\Dissertação\\resultado_experimentos\\data\\signatures\\full\\'
    
    dir1 = indir+'trip\\'
    dir2 = indir+'yelp\\'
    gab='trip-yelp'
    #exec_pap(headers, dir1, dir2, gab , outdir=indir+"z_resultado\\")
    
    dir1 = indir+'cnefe\\'
    dir2 = indir+'iptu\\'
    gab='cnefe-iptu'
    #exec_pap(headers, dir1, dir2, gab , outdir=indir+"z_resultado\\") #verificar
    
    dir1 = indir+'fda\\'
    dir2 = indir+'ca\\'
    gab='fda-ca'
    exec_pap(headers, dir1, dir2, gab , outdir=indir+"z_resultado\\")
    import sys
    sys.exit()
    
    dir1 = indir+'lei\\'
    dir2 = indir+'sec\\'
    gab='lei-sec'
    #result = exec_pap(headers, dir1, dir2, gab , outdir=indir+"z_resultado\\")
    
    
    dir1 = indir+'mpog\\'
    dir2 = indir+'tce\\'
    gab='mpog-tce'
    #exec_pap(headers, dir1, dir2, gab , outdir=indir+"z_resultado\\")
    
    import sys
    sys.exit()
    
    ### VOters
    #indir = 'F:\\Mestrado\\Acompanhamento\\SAC18\\experimentos\\exp_round_1\\signatures\\'
    
    dir1 = indir+'nc\\'
    dir2 = indir+'ohio\\'
    files_dir1 = check(dir1)
    files_dir2 = check(dir2)
    
    gab='nc-oh'
    gabarito = getGoldStandart(gab)
    